# practica-IA
Aquí vamos a subir los archivos necesarios para poder hacer la practicas de IA.
