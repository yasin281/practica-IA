# AIMAexample
Example of use of AIMA classes to complete in laboratory
