# AIMAexample
Example of use of AIMA classes to complete in laboratory: [COMPLETED]

#HOW TO COMPILE AIMA.zip  
1.Extract AIMA.zip

```
unzip AIMA.zip
```
2.If working on Linux execute the next command to include the library

```
export CLASSPATH=".:./dist/AIMA.jar"
```

3.Compile with javac

```
javac Main.java
```
4.Execute 
```
java Main
```