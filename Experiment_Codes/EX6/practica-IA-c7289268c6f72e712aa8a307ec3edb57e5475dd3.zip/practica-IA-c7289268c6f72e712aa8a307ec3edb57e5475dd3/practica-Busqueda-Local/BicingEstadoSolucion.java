import aima.search.framework.GoalTest;

public class BicingEstadoSolucion implements GoalTest {
    @Override
    public boolean isGoalState(Object aState) {
    return(false);
  }

}
